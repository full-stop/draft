/**
 * Created by Administrator on 2017/6/28.
 */
require('./build/all-task');