/**
 * @Author: gtshen
 * @Date:   2017-08-01T13:46:47+08:00
 * @Email:  sgt_ah@163.com
 * @Last modified by:   gtshen
 * @Last modified time: 2017-08-01T18:37:21+08:00
 */
var utl = require('../../../public/js/utils');
var t_zbList = require('../template/zbList.ejs');

var $progress = $('.progress-in');
var $rewardBtn = $('.reward-btn');
var $popSendGift = $('.pop-send-gift');
var $close = $('.close');
var $anchorDataBox = $('.anchor-data-box');
var $anchorBtns = $('.anchors span a');
var $reduce = $('.reduce');
var $add = $('.add');
var $giftNum = $('.pop-send-gift ul li em');
var $needMoney = $('.send-gift-tips strong');
var $sendGiftBtn = $('.send-gift-btn button');
var $portrait = $('.portrait li');

var giftNum = 0;

function sendGift(params) {
    $.get('/api/sendgift.htm', params, function(data) {
        if (data.errorCode === 0) {

        } else {
            utl.status(data.errorCode);
        }
    }, 'json')
}

function accdata() {
    $.get('/api/accdata.htm', function(data) {

        //设置礼物
        $add.off('click');
        $add.click(function() {
            if (data.errorCode === 0) {

                var money = data.bizObj.money1 * 1;

                if (money <= 0) {
                    alert('抱歉，您的钻石不足！');
                    return false;
                }

                if ($add.is('.disa')) {
                    return false;
                }

                $giftNum.html(++giftNum);
                $needMoney.html(giftNum);
                $reduce.removeClass('disa');

                if (giftNum >= money) {
                    $add.addClass('disa');
                    return false;
                }

            } else {
                utl.status(data.errorCode);
            }
        });

        $reduce.off('click');
        $reduce.click(function() {
            if (data.errorCode === 0) {

                var money = data.bizObj.money1 * 1;

                if ($reduce.is('.disa')) {
                    return false;
                }

                if (giftNum <= 0) {
                    $reduce.addClass('disa');
                    return false;
                }

                $giftNum.html(--giftNum);
                $needMoney.html(giftNum);
                $add.removeClass('disa');

                if (giftNum <= 0) {
                    $reduce.addClass('disa');
                    return false;
                }

            } else {
                utl.status(data.errorCode);
            }
        });

        //赠送礼物
        $sendGiftBtn.off('')
        $sendGiftBtn.click(function() {
            if (data.errorCode === 0) {
                if (data.bizObj.money1 >= 0) {
                    var index = $(this).index($sendGiftBtn.selector);
                    var sendCnt = 1;

                    if (index === 1) {
                        sendCnt = 3;
                    }

                    if (giftNum <= 0) {
                        alert('请选择礼物数量!');
                        return false;
                    }

                    sendGift({
                        "giftType": 1,
                        "giftNum": giftNum,
                        'sendCnt': sendCnt
                    });
                } else {
                    alert('抱歉，您的余额不足，请先充值！');
                }

            } else {
                utl.status(data.errorCode);
            }
        });

        if (data.errorCode === 0) {

            var powerValue = data.bizObj.powerValue * 1;
            var maxpowerValue = data.bizObj.maxpowerValue * 1;
            var ratio = powerValue / maxpowerValue * 100;

            // 进度条控制
            if (ratio > 100) {
                ratio = 100;
                powerValue = maxpowerValue;
            }
            $progress.width(ratio + '%');
            $progress.find('em').html(powerValue);
            $progress.find('strong').html(maxpowerValue);

            //写入当前钻石数量



        } else {
            utl.status(data.errorCode);
        }
    }, 'json');
}

//获取主播列表
function getAnchorList() {
    $.get('/api/getzbinfo.htm', function(data) {
        if (data.errorCode === 0) {
            $anchorDataBox.html(t_zbList(data.bizObj));
        } else if (data.errorCdoe != 30132) {
            utl.status(data.errorCode);
        }
    }, 'json');
}


//打赏主播
$rewardBtn.click(function() {
    utl.pop($popSendGift);

});

//关闭弹窗
$close.click(function() {
    utl.hidePop($popSendGift);
});

//主播信息切换
$anchorBtns.click(function() {
    var index = $(this).index($anchorBtns.selector);

    $anchorBtns.removeClass('hover');
    $(this).addClass('hover');
    $anchorDataBox.find('.anchor-infor').eq(index).show().siblings().hide();
    $portrait.eq(index).show().siblings().hide();
});

accdata();
getAnchorList();
