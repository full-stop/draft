/**
 * @Author: gtshen
 * @Date:   2017-08-01T15:25:00+08:00
 * @Email:  sgt_ah@163.com
 * @Last modified by:   gtshen
 * @Last modified time: 2017-08-01T18:19:39+08:00
 */



exports.pop = function(dom) {
    if (dom) {
        var $mask = $('.mask');
        var $pop = $('.pop');

        $pop.hide();
        dom.show();
        $mask.show();

    }
}

exports.hidePop = function(dom) {
    if (dom) {
        var $mask = $('.mask');
        dom.hide();
        $mask.hide();
    }
}

exports.status = function(errorCode, callcak) {
    switch (errorCode) {
        case 30132:
            callcak && callcak();
            break;
        case -200:
            alert('参数错误！');
            break;
        case -201:
            alert('余额不足！');
            break;
        default:
            alert('内部错误，错误编码：' + errorCode);
    }
}
